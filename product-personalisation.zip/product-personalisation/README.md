Product personalisation is a feature that allows users to add patterns, icons or text to their
selected product. 

1. When the module is enabled an "Engrave your device" section will appear below the swatch options on the 
pdp. 
2. Clicking on this section, a modal is launched with all the options specified for the module in addition
   to some product level specifications for preview view placement which is laid over the image carousel