export {default} from './shimmer.js';
