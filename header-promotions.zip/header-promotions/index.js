export { default } from './src/components/HeaderPromotions';
