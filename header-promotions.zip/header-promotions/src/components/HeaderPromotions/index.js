export { default } from './headerPromotions';
