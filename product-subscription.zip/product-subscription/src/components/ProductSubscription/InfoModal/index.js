export {default} from './infoModal';
