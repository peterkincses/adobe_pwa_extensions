export {default} from './src/components/StoreLocator';
