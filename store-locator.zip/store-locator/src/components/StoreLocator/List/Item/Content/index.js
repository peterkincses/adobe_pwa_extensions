export {default} from './content';
