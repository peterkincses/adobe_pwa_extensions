export {default} from './details';
