export {default} from './location';
