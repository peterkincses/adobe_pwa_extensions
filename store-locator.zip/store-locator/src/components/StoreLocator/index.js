export {default} from './storeLocator';
