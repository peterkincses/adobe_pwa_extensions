Store Locator pwa extension to work with MagePlaza's store locator module
